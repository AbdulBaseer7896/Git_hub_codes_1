        node * first =NULL;
        node * last= NULL;