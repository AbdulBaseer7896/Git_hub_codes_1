#include <iostream>
using namespace std;

class node
{
public:
    int data;
    node *next;
    node *head;

    node()
    {
        data = 0;
        next= NULL;
    }
    node(int value)
    {
        data = value;
        next = NULL;
    }

void del_first_node(int value)
{
    if (head == NULL)
    {
        cout << "list is empty";
    }
    else
    {

        node *temp;
        node *head;
        temp = head;
        head = head->next;
        free(temp);
        cout<<"done";
        // return head;
    }
}

void display()
{
    node  *ptr = head;
    while(ptr != NULL)
    {
        cout<<ptr->data<<endl;
		ptr = ptr->next;
    }
}
};
int main()
{
    node head;
    head.del_first_node(5);
    head.del_first_node(5);
    head.del_first_node(5);
    head.del_first_node(5);
    head.display();


    return 0;


    
}