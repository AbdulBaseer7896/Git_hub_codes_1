#include<iostream>
#include<vector>
#include <queue>
using namespace std;

void addEdg(vector<int> adj[] , int u, int v)
{
    adj[u].push_back(v);
    adj[v].push_back(u);
}

void printGraph(vector<int> adj[], int v)
{
    for(int i=0; i<v; i++)
    {
        cout<<i<<" = ";
        for(auto x: adj[i])
        {
            cout<<x<<" ->";
        }
        cout<<endl;
    }
}

void BFS_using_vector(vector<int> adj[] , int v , int sorce)
{
    vector<bool> visited(v+1 , false);
    queue<int>q;


    q.push(sorce);
    visited[sorce] = true;

    while(!q.emplace())
    {
        int u = q.front();
        q.pop();
        cout<<u<<" ->";

        for(int x: adj[u])
        {
            if(visited[x] == false)
            {
                visited[x] = true;
                cout<<x;
                q.push(x);
            }
        }

    }

}

vector<bool> v;
    vector<int> adj[5];
void bfs(int u , vector<int> adj[])
{
    cout<<"hello";
    queue<int> q;
 
    q.push(u);
    v[u] = true;
 
    while (!q.empty()) {
 
        int f = q.front();
        q.pop();
 
        cout << f << " ";
 
        // Enqueue all adjacent of f and mark them visited
        for (auto i = adj[f].begin(); i != adj[f].end(); i++) {
            if (!v[*i]) {
                q.push(*i);
                v[*i] = true;
            }
        }
    }
}

int main()
{

int vertes = 5;


    addEdg(adj, 0, 1);
    addEdg(adj, 0, 2);
    addEdg(adj, 1, 3);
    addEdg(adj, 1, 2);
    addEdg(adj, 2, 3);
    addEdg(adj, 2, 4);
    addEdg(adj, 3, 4);

    
    // addEdg(adj, 0, 1);
    // // addEdg(adj, 0, 2);
    // // addEdg(adj, 1, 3);
    // // addEdg(adj, 1, 2);
    // // addEdg(adj, 2, 3);
    // // addEdg(adj, 2, 4);
    // // addEdg(adj, 3, 4);


    printGraph(adj ,vertes);
    cout<<endl; 

    // BFS_using_vector(adj, vertes ,1);
    bfs(0, adj);
    
return 0;
}